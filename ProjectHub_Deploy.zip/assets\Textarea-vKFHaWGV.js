import{j as e}from"./index-T-BbWFdv.js";const d=({label:s,error:t,className:a="",...r})=>e.jsxs("div",{className:"w-full",children:[s&&e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5",children:s}),e.jsx("textarea",{className:`
          w-full px-3 py-2.5 
          bg-white dark:bg-slate-700/50 
          border border-slate-300 dark:border-slate-600 
          text-slate-900 dark:text-slate-50 
          placeholder-slate-400 dark:placeholder-slate-400
          rounded-lg 
          focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent 
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-all
          resize-none
          ${t?"border-red-500 focus:ring-red-500":""}
          ${a}
        `,...r}),t&&e.jsx("p",{className:"mt-1 text-sm text-red-600 dark:text-red-400",children:t})]});export{d as T};
