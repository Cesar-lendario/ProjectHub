import{j as e,X as b}from"./index-T-BbWFdv.js";const g=({isOpen:t,onClose:s,title:a,children:l,size:d="lg"})=>{if(!t)return null;const r={sm:"max-w-md",md:"max-w-lg",lg:"max-w-2xl",xl:"max-w-4xl","2xl":"max-w-6xl"};return e.jsx("div",{className:"fixed inset-0 bg-black/70 dark:bg-black/80 backdrop-blur-sm z-50 flex justify-center items-center p-4","aria-modal":"true",role:"dialog",children:e.jsxs("div",{className:`bg-white dark:bg-slate-800 rounded-xl shadow-2xl dark:shadow-2xl dark:shadow-black/50 w-full ${r[d]} max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-700`,children:[e.jsxs("div",{className:"flex justify-between items-center p-5 border-b border-slate-200 dark:border-slate-700",children:[e.jsx("h2",{className:"text-xl font-bold text-slate-900 dark:text-slate-50",children:a}),e.jsx("button",{onClick:s,className:"p-2 rounded-lg text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/50 hover:text-slate-700 dark:hover:text-slate-200 transition-all","aria-label":"Fechar modal",children:e.jsx(b,{className:"h-5 w-5"})})]}),e.jsx("div",{className:"flex-1 overflow-y-auto",children:l})]})})},m=({label:t,error:s,className:a="",...l})=>e.jsxs("div",{className:"w-full",children:[t&&e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5",children:t}),e.jsx("input",{className:`
          w-full px-3 py-2.5 
          bg-white dark:bg-slate-700/50 
          border border-slate-300 dark:border-slate-600 
          text-slate-900 dark:text-slate-50 
          placeholder-slate-400 dark:placeholder-slate-400
          rounded-lg 
          focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent 
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-all
          ${s?"border-red-500 focus:ring-red-500":""}
          ${a}
        `,...l}),s&&e.jsx("p",{className:"mt-1 text-sm text-red-600 dark:text-red-400",children:s})]}),f=({label:t,error:s,options:a,className:l="",...d})=>e.jsxs("div",{className:"w-full",children:[t&&e.jsx("label",{className:"block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5",children:t}),e.jsx("select",{className:`
          w-full px-3 py-2.5 
          bg-white dark:bg-slate-700/50 
          border border-slate-300 dark:border-slate-600 
          text-slate-900 dark:text-slate-50 
          rounded-lg 
          focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent 
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-all
          ${s?"border-red-500 focus:ring-red-500":""}
          ${l}
        `,...d,children:a.map(r=>e.jsx("option",{value:r.value,children:r.label},r.value))}),s&&e.jsx("p",{className:"mt-1 text-sm text-red-600 dark:text-red-400",children:s})]}),h=({children:t,variant:s="primary",size:a="md",fullWidth:l=!1,className:d="",disabled:r,...o})=>{const n="font-medium rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800 disabled:opacity-50 disabled:cursor-not-allowed",i={primary:"bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white focus:ring-indigo-500",secondary:"bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-900 dark:text-slate-50 focus:ring-slate-400",danger:"bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 text-white focus:ring-red-500",ghost:"bg-transparent hover:bg-slate-100 dark:hover:bg-slate-700/50 text-slate-700 dark:text-slate-200 focus:ring-slate-400"},c={sm:"px-3 py-1.5 text-sm",md:"px-4 py-2.5 text-sm",lg:"px-6 py-3 text-base"},x=l?"w-full":"";return e.jsx("button",{className:`${n} ${i[s]} ${c[a]} ${x} ${d}`,disabled:r,...o,children:t})};export{h as B,m as I,g as M,f as S};
